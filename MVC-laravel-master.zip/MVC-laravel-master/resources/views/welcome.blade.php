<!DOCTYPE html>
<html lang="en">

<head>
    <title>welcome</title>
</head>

<body>
    <h1>SELAMAT DATANG {{$firstname}} {{$lastname}}</h1>
    <h2>Terima kasih telah bergabung di SanberBook. Social Media kita Berasama!</h2>
</body>

</html>