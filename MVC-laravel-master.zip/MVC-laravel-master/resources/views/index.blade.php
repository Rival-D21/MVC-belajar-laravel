<!DOCTYPE html>
<html lang="en">

<head>
    <title>Belajar HTML</title>
</head>

<body>
    <div>
        <h1>SanberBook</h1>
        <h2>Social Media Developer Santai Berkualitas</h2>
        <p>Belajar dari Berbagi agar hidup ini semakin santai berkualitas</p>
    </div>
    <div>
        <h2>Benefit Join di SanberBook</h2>
        <ul>
            <li>Mendapatkan motivasi dari sesama Developer</li>
            <li>Sharing knowladge dari para mastah Sanber</li>
            <li>Dibuat oleh calon Developer terbaik</li>
        </ul>
    </div>
    <div>
        <h2>Cara Bergabung ke SanberBook</h2>
        <ol>
            <li>Mengunjungi Website ini</li>
            <li>Mendaftar di <a href="/register">Form Sign Up</a></li>
            <li>Selesai!</li>
        </ol>
    </div>
</body>

</html>